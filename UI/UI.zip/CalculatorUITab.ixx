module;


export module CalculatorUITab;